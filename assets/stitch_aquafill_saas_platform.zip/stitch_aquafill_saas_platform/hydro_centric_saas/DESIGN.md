---
name: Hydro-Centric SaaS
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#41474e'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#71787f'
  outline-variant: '#c0c7d0'
  surface-tint: '#1c6390'
  primary: '#004163'
  on-primary: '#ffffff'
  primary-container: '#075985'
  on-primary-container: '#96cfff'
  inverse-primary: '#90cdff'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#363f44'
  on-tertiary: '#ffffff'
  tertiary-container: '#4d565b'
  on-tertiary-container: '#c2cbd1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cbe6ff'
  primary-fixed-dim: '#90cdff'
  on-primary-fixed: '#001e31'
  on-primary-fixed-variant: '#004b72'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#dbe4ea'
  tertiary-fixed-dim: '#bfc8ce'
  on-tertiary-fixed: '#141d21'
  on-tertiary-fixed-variant: '#3f484d'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  h1:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin: 32px
---

## Brand & Style

The design system is built upon the pillars of purity, reliability, and flow. It targets a professional audience within the water utility and delivery sector, requiring a user interface that feels as clear and essential as the product it manages. 

The aesthetic follows a **Corporate / Modern** style with heavy influences from **Minimalism**. By prioritizing generous white space and a "liquid" visual rhythm, the design system evokes an immediate sense of hygiene and professional service. High-quality imagery of water droplets, condensation, and pristine service environments should be used to anchor the digital interface in the physical world.

## Colors

The palette centers on a "Deep Aqua" primary tone to establish authority and trust, while "Refreshing Cyan" accents provide a sense of vitality and action. 

- **Primary (Deep Aqua):** Used for navigation, primary actions, and brand-heavy components.
- **Secondary (Cyan):** Used for highlighting success states, active progress indicators, and interactive sparks.
- **Neutral:** A range of crisp whites for surfaces and deep slates for text to ensure high legibility and a "clean" feel.
- **Backgrounds:** Utilize the light tertiary blue for subtle section differentiation without breaking the minimalist aesthetic.

## Typography

The design system utilizes **Inter** for all typographic needs to maintain a utilitarian yet modern feel. The typeface’s tall x-height and neutral character make it ideal for data-heavy SaaS dashboards.

Headlines should utilize a tighter letter-spacing and heavier weight to appear grounded. Body text is optimized for readability with a generous line-height, ensuring that service logs and inventory lists remain clear at a glance.

## Layout & Spacing

The design system employs a **12-column fixed grid** for desktop, transitioning to a fluid single-column layout for mobile devices. The spacing rhythm is based on an **8px base unit**, creating a predictable and harmonious flow between elements.

Layouts should favor top-down hierarchies with "breathing room" around key metrics. Containers should use `md` (24px) padding as the default for internal content to maintain the "light and airy" brand promise.

## Elevation & Depth

To convey trust and professionalism, the design system uses **Ambient Shadows** that are exceptionally soft and tinted with a hint of the primary aqua color. 

Depth is structured through three levels:
1. **Base:** The primary background color, flat and crisp white.
2. **Surface:** Cards and containers with a subtle `1px` border in a light blue-gray and a very soft shadow (15% opacity, 20px blur).
3. **Overlay:** Modals and dropdowns with a more pronounced shadow to indicate temporary interaction, often accompanied by a light backdrop blur (glassmorphism) on the background to maintain focus.

## Shapes

The shape language is defined by **Soft Rounded Corners**. This removes the clinical "sharpness" often found in industrial software, replacing it with a more approachable and modern feel.

Standard components use a `0.5rem` radius. Larger containers like cards or feature panels use a `1rem` radius. This consistent curvature mimics the organic nature of water droplets while maintaining enough structure to feel professional.

## Components

The components within the design system are designed for high-frequency SaaS interactions:

- **Buttons:** Primary buttons feature a solid Deep Aqua fill with white text. Secondary buttons use a Cyan ghost style (outline) to provide clear hierarchy.
- **Input Fields:** Crisp white backgrounds with a `1px` border that transitions to a Cyan glow on focus. Labels are always positioned above the field for clarity.
- **Cards:** Used for water quality reports and delivery summaries. They should feature subtle borders and high-quality iconography.
- **Progress Indicators:** Circular gauges or linear bars using the Cyan accent to represent water levels or delivery completion.
- **Status Chips:** Small, pill-shaped badges with soft background tints (e.g., light green for "Purified," light blue for "In Transit").
- **Data Tables:** Clean, borderless rows with subtle hover states and generous vertical padding to avoid visual clutter.